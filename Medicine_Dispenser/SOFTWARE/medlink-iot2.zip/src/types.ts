/**
 * Types for MedLink IoT Smart Medicine Dispenser
 */

export type MedicineType = 'Tablet' | 'Capsule' | 'Softgel';

export interface Medicine {
  id: string;
  name: string;
  type: MedicineType;
  color: string; // hex or tailwind class name
  slot: 1 | 2 | 3;
  remainingPills: number;
  maxPills: number;
  dosePerReminder: number;
  repeatPattern: 'Daily' | 'Weekdays' | 'Custom';
  schedules: string[]; // e.g. ["08:00 AM", "09:00 PM"]
  enabled: boolean;
  category?: string; // e.g. "Antidiabetic", "Cholesterol", "Hypertension"
  instructions?: string; // e.g. "Take with food as prescribed"
}

export type LogStatus = 'Taken' | 'Missed' | 'Cancelled' | 'Failed';

export interface Log {
  id: string;
  timestamp: string; // ISO string
  medicineId?: string;
  medicineName: string;
  dosageText: string;
  status: LogStatus;
  detailText: string;
}

export interface HardwareComponent {
  id: string;
  name: string;
  description: string;
  status: 'Working' | 'Warning' | 'Offline';
  icon: string; // Lucide icon name or Material Symbol name
}

export interface DeviceConfig {
  connected: boolean;
  ssid: string;
  strength: number; // 0 to 4
  battery: number; // 0 to 100
  lastSync: string; // relative time or ISO string
  firmware: string;
  internalTemp: number; // in Celsius
}
