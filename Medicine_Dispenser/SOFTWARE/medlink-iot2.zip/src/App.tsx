import React, { useState, useEffect } from 'react';
import { Medicine, Log, HardwareComponent, DeviceConfig } from './types';
import {
  INITIAL_MEDICINES,
  INITIAL_LOGS,
  INITIAL_HARDWARE,
  INITIAL_CONFIG
} from './mockData';

// Import Views
import DashboardView from './components/DashboardView';
import MedicinesView from './components/MedicinesView';
import MedicineDetailsView from './components/MedicineDetailsView';
import AddEditMedicineView from './components/AddEditMedicineView';
import DiagnosticsView from './components/DiagnosticsView';
import LogsView from './components/LogsView';
import SettingsView from './components/SettingsView';
import WiFiSetupView from './components/WiFiSetupView';
import AboutView from './components/AboutView';
import DeviceSimulator from './components/DeviceSimulator';

export default function App() {
  // App-level state management with persistence
  const [medicines, setMedicines] = useState<Medicine[]>(() => {
    const saved = localStorage.getItem('medlink_medicines');
    return saved ? JSON.parse(saved) : INITIAL_MEDICINES;
  });

  const [logs, setLogs] = useState<Log[]>(() => {
    const saved = localStorage.getItem('medlink_logs');
    return saved ? JSON.parse(saved) : INITIAL_LOGS;
  });

  const [hardware, setHardware] = useState<HardwareComponent[]>(() => {
    const saved = localStorage.getItem('medlink_hardware');
    return saved ? JSON.parse(saved) : INITIAL_HARDWARE;
  });

  const [config, setConfig] = useState<DeviceConfig>(() => {
    const saved = localStorage.getItem('medlink_config');
    return saved ? JSON.parse(saved) : INITIAL_CONFIG;
  });

  // Screen Routing State
  const [currentScreen, setCurrentScreen] = useState<string>('home');
  const [selectedMedicineId, setSelectedMedicineId] = useState<string | null>(null);

  // App settings and UI toggles
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('medlink_darkmode');
    return saved === 'true';
  });

  const [showSimulator, setShowSimulator] = useState(true);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);

  // Active Dispensing Emulation State
  const [dispensingState, setDispensingState] = useState<{
    active: boolean;
    medicineName: string;
    pillCount: number;
    color: string;
    slot: number;
    medId: string;
  } | null>(null);

  // Sync state changes to localStorage
  useEffect(() => {
    localStorage.setItem('medlink_medicines', JSON.stringify(medicines));
  }, [medicines]);

  useEffect(() => {
    localStorage.setItem('medlink_logs', JSON.stringify(logs));
  }, [logs]);

  useEffect(() => {
    localStorage.setItem('medlink_hardware', JSON.stringify(hardware));
  }, [hardware]);

  useEffect(() => {
    localStorage.setItem('medlink_config', JSON.stringify(config));
  }, [config]);

  useEffect(() => {
    localStorage.setItem('medlink_darkmode', String(isDarkMode));
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Toast self-dismiss helper
  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => setToast(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'info') => {
    setToast({ message, type });
  };

  // State mutation actions
  const handleSaveMedicine = (medData: Omit<Medicine, 'id'> & { id?: string }) => {
    if (medData.id) {
      // Editing
      setMedicines(prev =>
        prev.map(m => (m.id === medData.id ? { ...m, ...medData, id: m.id } : m))
      );
      
      const newLog: Log = {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        medicineName: medData.name,
        dosageText: `${medData.dosePerReminder} Pill Schedule Adjusted`,
        status: 'Taken',
        detailText: `Medication config changed. Dispenser Slot #${medData.slot} updated.`
      };
      setLogs(prev => [newLog, ...prev]);
      showToast(`${medData.name} updated successfully.`, 'success');
      setCurrentScreen('medicines');
    } else {
      // Adding new
      const newMed: Medicine = {
        ...medData,
        id: `med-${Date.now()}`
      };
      setMedicines(prev => [...prev, newMed]);

      const newLog: Log = {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        medicineName: medData.name,
        dosageText: `Slot Assigned: Slot #${medData.slot}`,
        status: 'Taken',
        detailText: `New reminder added: ${medData.name} scheduled for ${medData.schedules.join(', ')}.`
      };
      setLogs(prev => [newLog, ...prev]);
      showToast(`${medData.name} added to Slot #${medData.slot}.`, 'success');
      setCurrentScreen('medicines');
    }
  };

  const handleToggleEnabled = (id: string, enabled: boolean) => {
    setMedicines(prev => prev.map(m => (m.id === id ? { ...m, enabled } : m)));
    const target = medicines.find(m => m.id === id);
    if (target) {
      const newLog: Log = {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        medicineName: target.name,
        dosageText: enabled ? 'Reminders Enabled' : 'Reminders Silenced',
        status: 'Cancelled',
        detailText: `Dispenser schedule for ${target.name} has been ${enabled ? 'reactivated' : 'temporarily paused'}.`
      };
      setLogs(prev => [newLog, ...prev]);
      showToast(`${target.name} ${enabled ? 'enabled' : 'disabled'}.`);
    }
  };

  const handleRefillMedicine = (id: string) => {
    setMedicines(prev =>
      prev.map(m => (m.id === id ? { ...m, remainingPills: m.maxPills } : m))
    );
    const target = medicines.find(m => m.id === id);
    if (target) {
      const newLog: Log = {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        medicineName: target.name,
        dosageText: `Refilled to ${target.maxPills} Pills`,
        status: 'Taken',
        detailText: `Dispenser cartridge Slot #${target.slot} loaded with ${target.maxPills} fresh tablets.`
      };
      setLogs(prev => [newLog, ...prev]);
      showToast(`${target.name} inventory replenished!`, 'success');
    }
  };

  const handleRefillAll = () => {
    setMedicines(prev => prev.map(m => ({ ...m, remainingPills: m.maxPills })));
    const newLog: Log = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      medicineName: 'All Medications',
      dosageText: 'System Inventory Refilled',
      status: 'Taken',
      detailText: 'Full hardware replenishment executed. All dispenser slots loaded to capacity.'
    };
    setLogs(prev => [newLog, ...prev]);
    showToast('All medications refilled to capacity.', 'success');
  };

  const handleDeleteMedicine = (id: string) => {
    const target = medicines.find(m => m.id === id);
    setMedicines(prev => prev.filter(m => m.id !== id));
    if (target) {
      const newLog: Log = {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        medicineName: target.name,
        dosageText: 'Schedule Deleted',
        status: 'Cancelled',
        detailText: `Dispenser Slot #${target.slot} unassigned. Medication schedule removed.`
      };
      setLogs(prev => [newLog, ...prev]);
      showToast(`${target.name} schedule removed.`);
    }
    setCurrentScreen('medicines');
  };

  const handleTestComponent = (id: string) => {
    setHardware(prev =>
      prev.map(h => (h.id === id ? { ...h, status: 'Working' } : h))
    );
    const comp = hardware.find(h => h.id === id);
    if (comp) {
      const newLog: Log = {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        medicineName: 'Hardware Diagnostic',
        dosageText: `${comp.name} Test`,
        status: 'Taken',
        detailText: `Manual actuator test command executed for ${comp.name}. Diagnostic returned OK.`
      };
      setLogs(prev => [newLog, ...prev]);
      showToast(`${comp.name} test returned OK!`, 'success');
    }
  };

  const handleResetComponent = (id: string) => {
    setHardware(prev =>
      prev.map(h => (h.id === id ? { ...h, status: 'Working' } : h))
    );
    const comp = hardware.find(h => h.id === id);
    if (comp) {
      const newLog: Log = {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        medicineName: 'Hardware Reset',
        dosageText: `${comp.name} Reboot`,
        status: 'Taken',
        detailText: `Controller reset signal pushed to ${comp.name}. Communication link recovered.`
      };
      setLogs(prev => [newLog, ...prev]);
      showToast(`${comp.name} link recovered!`, 'success');
    }
  };

  const handleRunFullDiagnostics = async () => {
    setHardware(prev => prev.map(h => ({ ...h, status: 'Working' })));
    const newLog: Log = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      medicineName: 'Full Diagnostic Suite',
      dosageText: 'Chassis Check Completed',
      status: 'Taken',
      detailText: 'Full hardware check completed. Stepper motors, OLED controllers, and sensors verified OK.'
    };
    setLogs(prev => [newLog, ...prev]);
    showToast('All hardware systems running nominally!', 'success');
  };

  // Simulating ESP32 restart sequence
  const handleRestartDevice = () => {
    setConfig(prev => ({ ...prev, connected: false }));
    showToast('Dispenser Hub rebooting... link offline.', 'error');
    
    setTimeout(() => {
      setConfig(prev => ({ ...prev, connected: true, lastSync: 'Just now' }));
      const newLog: Log = {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        medicineName: 'Hub System',
        dosageText: 'ESP32 Rebooted',
        status: 'Taken',
        detailText: 'Physical smart hub system completed restart sequence. Synchronized with AWS cloud node.'
      };
      setLogs(prev => [newLog, ...prev]);
      showToast('Dispenser Hub online. Telemetry recovered.', 'success');
    }, 2500);
  };

  // Set WiFi Config
  const handleSaveWiFiConfig = (ssidName: string) => {
    setConfig(prev => ({ ...prev, ssid: ssidName, lastSync: 'Just now' }));
    showToast(`Smart Dispenser linked to network: ${ssidName}`, 'success');
  };

  // Triggering the Dispensing simulator
  const handleTriggerDispense = (med: Medicine) => {
    if (!config.connected) {
      showToast('Dispense failed: Smart Hub is currently offline.', 'error');
      return;
    }
    setDispensingState({
      active: true,
      medicineName: med.name,
      pillCount: med.dosePerReminder,
      color: med.color,
      slot: med.slot,
      medId: med.id
    });
    setShowSimulator(true);
    showToast(`IoT Dispense initiated: Slot #${med.slot} rotating...`, 'info');
  };

  // Completing dispensing and updating inventory
  const handleTakePill = () => {
    if (!dispensingState) return;

    setMedicines(prev =>
      prev.map(m =>
        m.id === dispensingState.medId
          ? { ...m, remainingPills: Math.max(0, m.remainingPills - dispensingState.pillCount) }
          : m
      )
    );

    const newLog: Log = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      medicineName: dispensingState.medicineName,
      dosageText: `Slot #${dispensingState.slot} • ${dispensingState.pillCount} Pill(s) Taken`,
      status: 'Taken',
      detailText: `Dispensed successfully from SmartBox Slot A${dispensingState.slot}. Daily streak continues!`
    };
    setLogs(prev => [newLog, ...prev]);
    setDispensingState(null);
    showToast('Medication taken! Streak & Adherence logs updated.', 'success');
  };

  // Cancelling dispensing midway
  const handleCancelDispense = () => {
    if (!dispensingState) return;

    const newLog: Log = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      medicineName: dispensingState.medicineName,
      dosageText: `Slot #${dispensingState.slot} • Skipped`,
      status: 'Cancelled',
      detailText: 'Dispense sequence cancelled by the companion mobile application.'
    };
    setLogs(prev => [newLog, ...prev]);
    setDispensingState(null);
    showToast('Dispensing sequence terminated.');
  };

  // Caregiver Emergency Dispense Override
  const handleEmergencyDispense = () => {
    const activeMeds = medicines.filter(m => m.enabled && m.remainingPills > 0);
    const med = activeMeds[0] || medicines[0];

    if (!med) {
      showToast('No medicines loaded in dispenser slots.', 'error');
      return;
    }

    if (confirm('CRITICAL WARN: Trigger an immediate manual override dispense of 1 tablet?')) {
      setDispensingState({
        active: true,
        medicineName: `${med.name} (EMERGENCY)`,
        pillCount: 1,
        color: med.color,
        slot: med.slot,
        medId: med.id
      });
      setShowSimulator(true);
      
      const newLog: Log = {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        medicineName: 'Emergency Dispense',
        dosageText: 'Caregiver Manual Override',
        status: 'Taken',
        detailText: `Emergency override button pressed on mobile. 1 Pill dispensed from Slot #${med.slot}.`
      };
      setLogs(prev => [newLog, ...prev]);
      showToast('EMERGENCY COMMAND: Dispensing pill immediately!', 'success');
    }
  };

  // Router for views inside our device mockup
  const renderScreenContent = () => {
    switch (currentScreen) {
      case 'home':
        return (
          <DashboardView
            medicines={medicines}
            logs={logs}
            config={config}
            onNavigate={(scr, id) => {
              setCurrentScreen(scr);
              if (id) setSelectedMedicineId(id);
            }}
            onRefillAll={handleRefillAll}
            onTriggerDispense={handleTriggerDispense}
            onEmergencyDispense={handleEmergencyDispense}
          />
        );
      case 'medicines':
        return (
          <MedicinesView
            medicines={medicines}
            logs={logs}
            onNavigate={(scr, id) => {
              setCurrentScreen(scr);
              if (id) setSelectedMedicineId(id);
            }}
            onToggleEnabled={handleToggleEnabled}
          />
        );
      case 'diagnostics':
        return (
          <DiagnosticsView
            hardware={hardware}
            onTestComponent={handleTestComponent}
            onResetComponent={handleResetComponent}
            onRunFullDiagnostics={handleRunFullDiagnostics}
            internalTemp={config.internalTemp}
          />
        );
      case 'settings':
        return (
          <SettingsView
            config={config}
            onNavigate={setCurrentScreen}
            onRestartDevice={handleRestartDevice}
            isDarkMode={isDarkMode}
            onToggleDarkMode={() => setIsDarkMode(!isDarkMode)}
          />
        );
      case 'details':
        const selectedMed = medicines.find(m => m.id === selectedMedicineId) || null;
        return (
          <MedicineDetailsView
            medicine={selectedMed}
            onNavigate={(scr, id) => {
              setCurrentScreen(scr);
              if (id) setSelectedMedicineId(id);
            }}
            onRefill={handleRefillMedicine}
            onTriggerDispense={handleTriggerDispense}
            onDelete={handleDeleteMedicine}
          />
        );
      case 'add-edit':
        return (
          <AddEditMedicineView
            medicineId={selectedMedicineId}
            medicines={medicines}
            onSave={handleSaveMedicine}
            onNavigate={(scr, id) => {
              setCurrentScreen(scr);
              if (id) setSelectedMedicineId(id);
            }}
          />
        );
      case 'wifi-setup':
        return (
          <WiFiSetupView
            currentSSID={config.ssid}
            onSaveConfig={handleSaveWiFiConfig}
            onNavigate={setCurrentScreen}
          />
        );
      case 'about':
        return <AboutView onNavigate={setCurrentScreen} />;
      case 'logs-list':
        return (
          <LogsView
            logs={logs}
            onClearLogs={() => setLogs([])}
            onNavigate={setCurrentScreen}
          />
        );
      default:
        return <div className="text-center p-4">Screen not found</div>;
    }
  };

  // Determine standard tab highlights
  const getTabClass = (tabName: string) => {
    const isTabActive = 
      (tabName === 'home' && currentScreen === 'home') ||
      (tabName === 'medicines' && (currentScreen === 'medicines' || currentScreen === 'details' || currentScreen === 'add-edit')) ||
      (tabName === 'diagnostics' && currentScreen === 'diagnostics') ||
      (tabName === 'settings' && (currentScreen === 'settings' || currentScreen === 'wifi-setup' || currentScreen === 'about' || currentScreen === 'logs-list'));

    return isTabActive
      ? 'flex flex-col items-center justify-center bg-[#7cf994] text-[#007230] rounded-full px-5 py-1 transition-all duration-300 font-bold active:scale-95'
      : 'flex flex-col items-center justify-center text-[#434655] dark:text-[#c3c6d7] px-4 py-1 hover:bg-[#e7eeff] hover:text-[#004ac6] dark:hover:bg-slate-800 rounded-xl transition-all duration-200 active:scale-90';
  };

  return (
    <div className={`min-h-screen flex flex-col items-center justify-center py-6 px-4 ${isDarkMode ? 'dark bg-[#111c2d]' : 'bg-slate-100'}`}>
      
      {/* Toast Notification Banner */}
      {toast && (
        <div className={`fixed top-4 z-50 px-5 py-3 rounded-2xl shadow-lg border text-xs font-bold flex items-center gap-2 animate-bounce ${
          toast.type === 'success' ? 'bg-[#7cf994] text-[#007230] border-[#62df7d]' :
          toast.type === 'error' ? 'bg-[#ffdad6] text-[#ba1a1a] border-[#ffdad6]' :
          'bg-[#dee8ff] text-[#004ac6] border-[#004ac6]/10'
        }`}>
          <span className="material-symbols-outlined text-base">
            {toast.type === 'success' ? 'check_circle' : toast.type === 'error' ? 'error' : 'info'}
          </span>
          <span>{toast.message}</span>
        </div>
      )}

      {/* Primary layout split container */}
      <div className="w-full max-w-5xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left/Middle Column: Handheld Smartphone Frame Mockup */}
        <div className="lg:col-span-7 flex justify-center">
          <div className="relative w-full max-w-sm h-[780px] bg-slate-900 rounded-[50px] shadow-2xl p-4 border-[10px] border-slate-800 flex flex-col overflow-hidden relative group">
            {/* Phone Speaker & Notch pill camera cut out */}
            <div className="absolute top-0 left-1/2 -translate-y-1/2 w-40 h-8 bg-slate-900 rounded-b-3xl z-50 flex items-center justify-center px-4">
              <div className="w-16 h-1 bg-slate-800 rounded-full mb-1"></div>
              <div className="w-3.5 h-3.5 rounded-full bg-[#111c2d] ml-2 border-2 border-slate-800 mb-1"></div>
            </div>

            {/* Smart Phone screen container */}
            <div className="flex-1 bg-[#f9f9ff] dark:bg-slate-900 rounded-[36px] overflow-hidden flex flex-col relative select-none">
              
              {/* Virtual Handheld Status Bar */}
              <header className="w-full h-10 px-6 pt-2 shrink-0 flex justify-between items-center bg-[#f9f9ff] dark:bg-slate-900 text-xs font-semibold text-[#111c2d] dark:text-white z-40 select-none">
                <span className="font-mono text-[10px] tracking-tight">10:08 AM</span>
                <div className="flex items-center gap-1.5 text-xs">
                  <span className={`material-symbols-outlined text-sm ${config.connected ? 'text-green-600' : 'text-red-500 animate-pulse'}`}>
                    {config.connected ? 'wifi' : 'wifi_off'}
                  </span>
                  <span className="material-symbols-outlined text-sm">battery_charging_80</span>
                </div>
              </header>

              {/* Top Custom App Bar matching specs */}
              <div className="w-full flex justify-between items-center px-6 py-2 bg-[#f9f9ff] dark:bg-slate-900 text-[#111c2d] dark:text-white shrink-0 border-b border-[#cbd5e1]/10">
                <div className="flex items-center gap-2">
                  <div className="w-9 h-9 rounded-full bg-[#dee8ff] border border-blue-500/20 flex items-center justify-center overflow-hidden">
                    <img
                      className="w-full h-full object-cover"
                      alt="Doctor/Caregiver Portrait"
                      referrerPolicy="no-referrer"
                      src="https://lh3.googleusercontent.com/aida-public/AB6AXuC7enPGJe9NWxWiOJ57VzHOS_R426llmibaCl2OEG6GSxRA1HAXccSKH1bWhCc8jur_TgOAW79FFztKQDYxc5pSPLSvY3SMsCbJywtaFpQTsn40xm2sxXQziKxN0NwzqWJbyhdj2dh1fPItbuLmrQ8HO0szVhOuJRJuqeaDnEiXiHO1m6hQgS2ixsiFwBDqrAkZcAkBBh8pAZG_yXgUGFkzm2xGGbSAybWedhIXR2fmsaPeTXQiOhfdnw"
                    />
                  </div>
                  <h1 className="text-base font-bold text-[#004ac6] dark:text-[#7cf994] font-sans">MedLink IoT</h1>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setCurrentScreen('logs-list');
                    showToast('History logs opened.');
                  }}
                  className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-slate-200/50 dark:hover:bg-slate-800 transition-colors"
                >
                  <span className="material-symbols-outlined text-xl text-[#004ac6] dark:text-white">notifications</span>
                </button>
              </div>

              {/* Handheld Scrollable Viewport Canvas */}
              <main className="flex-1 overflow-y-auto px-5 py-4 pb-20 scrollbar-none scroll-smooth">
                {renderScreenContent()}
              </main>

              {/* Handheld Mobile Navigation Tab Bar */}
              <nav className="absolute bottom-0 left-0 w-full h-[64px] bg-[#e7eeff] dark:bg-slate-900 border-t border-[#cbd5e1]/20 flex justify-around items-center px-3 pb-safe z-40 select-none shadow-[0_-2px_10px_rgba(0,0,0,0.02)]">
                <button
                  type="button"
                  onClick={() => {
                    setCurrentScreen('home');
                    setSelectedMedicineId(null);
                  }}
                  className={getTabClass('home')}
                >
                  <span className="material-symbols-outlined text-lg">dashboard</span>
                  <span className="text-[9px] font-semibold tracking-wider uppercase mt-0.5">Home</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setCurrentScreen('medicines');
                    setSelectedMedicineId(null);
                  }}
                  className={getTabClass('medicines')}
                >
                  <span className="material-symbols-outlined text-lg">medication</span>
                  <span className="text-[9px] font-semibold tracking-wider uppercase mt-0.5">Medicines</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setCurrentScreen('diagnostics');
                    setSelectedMedicineId(null);
                  }}
                  className={getTabClass('diagnostics')}
                >
                  <span className="material-symbols-outlined text-lg">medical_services</span>
                  <span className="text-[9px] font-semibold tracking-wider uppercase mt-0.5">Diagnostics</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setCurrentScreen('settings');
                    setSelectedMedicineId(null);
                  }}
                  className={getTabClass('settings')}
                >
                  <span className="material-symbols-outlined text-lg">settings</span>
                  <span className="text-[9px] font-semibold tracking-wider uppercase mt-0.5">Settings</span>
                </button>
              </nav>

            </div>
          </div>
        </div>

        {/* Right Column: ESP32 Smart Dispenser physical hardware simulator panel */}
        <div className="lg:col-span-5 space-y-4">
          
          {/* Toggle simulator visibility button */}
          <div className="flex justify-between items-center bg-[#263143]/10 border border-[#c3c6d7]/20 p-4 rounded-2xl shadow-sm text-slate-800 dark:text-white">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400">
                ESP32 Hardware Simulation
              </h3>
              <p className="text-[10px] text-slate-400 mt-0.5">
                Emulates physical pill drop physics and OLED feedback signals.
              </p>
            </div>
            <button
              onClick={() => setShowSimulator(!showSimulator)}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all shadow-sm active:scale-95 ${
                showSimulator 
                  ? 'bg-red-500/10 border border-red-500/20 text-red-500' 
                  : 'bg-[#004ac6] text-white hover:bg-[#2563eb]'
              }`}
            >
              {showSimulator ? 'Close simulator' : 'Open hardware'}
            </button>
          </div>

          {/* Render the tactile Device Simulator */}
          {showSimulator && (
            <div className="animate-fade-in">
              <DeviceSimulator
                dispensingState={dispensingState}
                onTakePill={handleTakePill}
                onCancelDispense={handleCancelDispense}
                ssid={config.ssid}
              />
            </div>
          )}

          {/* Quick instructions / Help Card */}
          <div className="bg-[#dee8ff]/30 p-5 rounded-3xl border border-[#cbd5e1]/30 space-y-3 text-slate-800 dark:text-white">
            <h4 className="text-xs font-bold text-[#004ac6] uppercase tracking-wider">
              Hackathon Demonstration Guide
            </h4>
            <ul className="space-y-2 text-xs">
              <li className="flex gap-2 items-start">
                <span className="text-green-600 font-bold shrink-0">✓</span>
                <span>Click <strong>Take Now</strong> or <strong>Dispense Test</strong> on the phone UI to trigger physical motor rotation on the ESP32 mockup.</span>
              </li>
              <li className="flex gap-2 items-start">
                <span className="text-green-600 font-bold shrink-0">✓</span>
                <span>Watch the <strong>OLED display updates</strong>, blinking status LEDs, and a physical round pill release into the cup.</span>
              </li>
              <li className="flex gap-2 items-start">
                <span className="text-green-600 font-bold shrink-0">✓</span>
                <span>Click <strong>"Take Medicine Pill"</strong> on the hardware to deduct inventory, log success metrics, and increase streak adherence.</span>
              </li>
              <li className="flex gap-2 items-start">
                <span className="text-green-600 font-bold shrink-0">✓</span>
                <span>Navigate to <strong>Diagnostics</strong> inside Settings or bottom navigation to trigger hardware checks and reboot tests.</span>
              </li>
            </ul>
          </div>

        </div>

      </div>
    </div>
  );
}
