import React, { useEffect, useState } from 'react';
import { Medicine } from '../types';

interface DeviceSimulatorProps {
  dispensingState: {
    active: boolean;
    medicineName: string;
    pillCount: number;
    color: string;
    slot: number;
  } | null;
  onTakePill: () => void;
  onCancelDispense: () => void;
  ssid: string;
}

export default function DeviceSimulator({
  dispensingState,
  onTakePill,
  onCancelDispense,
  ssid
}: DeviceSimulatorProps) {
  const [motorRotation, setMotorRotation] = useState(0);
  const [oledText, setOledText] = useState('MEDLINK HUB OK');
  const [ledStatus, setLedStatus] = useState<'solid_green' | 'blink_blue' | 'solid_red'>('solid_green');
  const [pillsInChute, setPillsInChute] = useState<Array<{ id: number; color: string; dropped: boolean }>>([]);

  // Telemetry status updates during dispensing
  useEffect(() => {
    if (dispensingState) {
      setLedStatus('blink_blue');
      setOledText('CMD RECEIVED...');
      
      // Step 1: Initialize rotation
      const step1 = setTimeout(() => {
        setOledText(`ROTATING SLOT ${dispensingState.slot}`);
        setMotorRotation(360);
      }, 800);

      // Step 2: Drop Pill
      const step2 = setTimeout(() => {
        setOledText(`RELEASING PILL...`);
        setPillsInChute(prev => [
          ...prev, 
          { id: Date.now(), color: dispensingState.color, dropped: true }
        ]);
        // Simple synth audio beep indicator for accessible dispensing confirmation
        try {
          const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
          const osc = audioCtx.createOscillator();
          const gain = audioCtx.createGain();
          osc.connect(gain);
          gain.connect(audioCtx.destination);
          osc.frequency.value = 880; // High frequency beep
          gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
          osc.start();
          gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
          osc.stop(audioCtx.currentTime + 0.3);
        } catch (e) {
          console.log('Audio synthesis not supported or gesture required.');
        }
      }, 1800);

      // Step 3: Complete & Prompt Taking
      const step3 = setTimeout(() => {
        setOledText(`TAKE PILL! (SLOT ${dispensingState.slot})`);
        setLedStatus('solid_green');
      }, 2800);

      return () => {
        clearTimeout(step1);
        clearTimeout(step2);
        clearTimeout(step3);
      };
    } else {
      setLedStatus('solid_green');
      setOledText(`SSID: ${ssid || 'DISCONNECTED'}`);
      setMotorRotation(0);
    }
  }, [dispensingState, ssid]);

  return (
    <div className="bg-[#263143] text-white p-5 rounded-3xl border border-[#434655]/50 shadow-xl space-y-4 max-w-sm mx-auto relative overflow-hidden">
      {/* ESP32 hardware decal branding */}
      <div className="absolute top-2.5 right-4 font-mono text-[8px] text-white/30 tracking-widest uppercase">
        ESP32-S3 CORE IoT v2.4
      </div>

      <div className="flex items-center gap-2">
        <span className="w-2 h-2 rounded-full bg-[#7cf994] animate-ping shrink-0" />
        <h3 className="text-xs font-mono uppercase tracking-widest text-[#7cf994] font-bold">
          Physical Hardware Simulation
        </h3>
      </div>

      {/* Main Dispenser Chassis Frame Mock */}
      <div className="bg-[#111c2d] border border-[#737686]/20 rounded-2xl p-4 space-y-4 shadow-inner relative">
        
        {/* Status Indicators Panel */}
        <div className="flex justify-between items-center bg-[#263143]/40 px-3 py-2 rounded-xl border border-white/5">
          <div className="flex items-center gap-3">
            {/* LED Status Indicator Lights */}
            <div className="flex flex-col items-center">
              <div className={`w-3.5 h-3.5 rounded-full shadow-md transition-all ${
                ledStatus === 'solid_green' ? 'bg-[#7cf994] shadow-[#7cf994]/50' :
                ledStatus === 'blink_blue' ? 'bg-blue-400 animate-pulse shadow-blue-400/50' :
                'bg-red-500 shadow-red-500/50'
              }`} />
              <span className="text-[7px] font-mono text-white/50 uppercase mt-1">SYS LED</span>
            </div>

            <div className="flex flex-col items-center">
              <div className={`w-3.5 h-3.5 rounded-full shadow-md transition-all bg-[#fbbf24] shadow-amber-400/50 ${
                dispensingState ? 'animate-bounce' : ''
              }`} />
              <span className="text-[7px] font-mono text-white/50 uppercase mt-1">MOTOR</span>
            </div>
          </div>

          {/* Wi-Fi RSSI label */}
          <div className="text-right">
            <p className="text-[8px] font-mono text-[#7cf994] leading-none">RSSI: -42dBm</p>
            <p className="text-[7px] font-mono text-white/40 uppercase mt-0.5">Antenna Active</p>
          </div>
        </div>

        {/* Simulated OLED micro-controller screen display */}
        <div className="bg-black border-2 border-[#737686]/30 rounded-lg p-3 h-14 font-mono flex flex-col justify-center shadow-inner relative overflow-hidden">
          <div className="absolute inset-0 bg-blue-500/5 pointer-events-none" />
          <p className="text-[10px] text-blue-400 uppercase tracking-widest leading-none">OLED SSD1306</p>
          <p className="text-xs text-blue-300 font-bold tracking-tight mt-1 animate-pulse select-none">
            {oledText}
          </p>
        </div>

        {/* Mechanical Actuator Section: Spinning Circular Stepper Motor */}
        <div className="flex justify-around items-center py-2 bg-[#263143]/20 rounded-xl border border-white/5">
          <div className="text-center space-y-1">
            <span className="text-[8px] font-mono text-white/40 uppercase block">Actuator A1</span>
            <div 
              className="w-10 h-10 rounded-full border-4 border-dashed border-[#fbbf24] flex items-center justify-center transition-all duration-1000 ease-out"
              style={{ transform: `rotate(${motorRotation}deg)` }}
            >
              <div className="w-3 h-3 rounded-full bg-white/30" />
            </div>
          </div>

          <div className="text-center space-y-1">
            <span className="text-[8px] font-mono text-white/40 uppercase block">Actuator A2</span>
            <div 
              className="w-10 h-10 rounded-full border-4 border-[#dee8ff]/10 flex items-center justify-center"
            >
              <div className="w-1.5 h-5 bg-[#7cf994]/30 rounded-full" />
            </div>
          </div>
        </div>

        {/* Chute drop area representation */}
        <div className="bg-black/40 border border-[#737686]/10 rounded-xl h-24 relative overflow-hidden flex flex-col justify-end items-center pb-2">
          <span className="absolute top-1.5 text-[8px] font-mono text-white/30 uppercase tracking-wider">
            Dispensing Cup (Chute)
          </span>

          {/* Dropping pills animations */}
          <div className="absolute inset-x-0 top-0 flex justify-center">
            {pillsInChute.map(pill => (
              <div
                key={pill.id}
                className="w-5 h-5 rounded-full shadow-lg border-2 border-white/20 flex items-center justify-center text-white/80 font-bold text-[8px] transition-all duration-700 ease-bounce"
                style={{
                  backgroundColor: pill.color,
                  transform: pill.dropped ? 'translateY(56px) scale(1.1)' : 'translateY(0) scale(0.5)',
                }}
              >
                P
              </div>
            ))}
          </div>

          {pillsInChute.length > 0 ? (
            <button
              type="button"
              onClick={() => {
                setPillsInChute([]);
                onTakePill();
              }}
              className="z-10 bg-[#7cf994] hover:bg-[#62df7d] text-[#002109] text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider shadow active:scale-95 transition-all"
            >
              Take Medicine Pill
            </button>
          ) : (
            <p className="text-[9px] font-mono text-white/20 select-none italic pb-1">
              Dispense cup is currently empty
            </p>
          )}
        </div>
      </div>

      {/* Control Actions */}
      {dispensingState && (
        <div className="flex gap-2">
          <button
            type="button"
            onClick={onCancelDispense}
            className="flex-1 py-1.5 bg-[#434655] hover:bg-gray-700 text-white rounded-xl text-[10px] uppercase tracking-wider font-bold transition-all"
          >
            Cancel Run
          </button>
        </div>
      )}
    </div>
  );
}
