import React from 'react';
import { DeviceConfig } from '../types';

interface SettingsViewProps {
  config: DeviceConfig;
  onNavigate: (screen: string) => void;
  onRestartDevice: () => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
}

export default function SettingsView({
  config,
  onNavigate,
  onRestartDevice,
  isDarkMode,
  onToggleDarkMode
}: SettingsViewProps) {
  return (
    <div className="space-y-6 pt-2">
      {/* Hero Section / Dispenser Hub Status */}
      <section className="bg-white border border-[#c3c6d7]/30 shadow-sm rounded-2xl p-5 flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-[#111c2d]">Dispenser Status</h2>
          <p className="text-xs font-semibold text-[#006e2d] flex items-center gap-1 mt-1">
            <span className="material-symbols-outlined text-[15px] fill-icon">check_circle</span>
            <span>Connected &amp; Active</span>
          </p>
        </div>
        <div className="relative w-14 h-14 flex items-center justify-center shrink-0">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
            <circle cx="18" cy="18" r="15.915" fill="none" stroke="#e7eeff" strokeWidth="3" />
            <circle
              cx="18"
              cy="18"
              r="15.915"
              fill="none"
              stroke="#2563eb"
              strokeWidth="3"
              strokeDasharray="82 100"
              strokeLinecap="round"
            />
          </svg>
          <span className="absolute text-[10px] font-mono font-bold text-[#2563eb]">82%</span>
        </div>
      </section>

      {/* Settings Groups: Bento Layout Inspired */}
      <div className="grid grid-cols-1 gap-6">
        {/* Device Section */}
        <section className="space-y-3">
          <div className="flex items-center gap-2 px-1 text-[#737686]">
            <span className="material-symbols-outlined text-base">devices</span>
            <h3 className="text-[10px] font-bold uppercase tracking-wider">Device Hardware</h3>
          </div>

          <div className="space-y-2.5">
            {/* WiFi Config */}
            <button
              onClick={() => onNavigate('wifi-setup')}
              className="w-full flex items-center justify-between p-4 bg-white rounded-xl shadow-sm border border-[#c3c6d7]/20 hover:bg-[#f0f3ff] transition-colors text-left"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-full bg-[#2563eb] text-white flex items-center justify-center">
                  <span className="material-symbols-outlined text-lg">wifi</span>
                </div>
                <div>
                  <div className="text-xs font-bold text-[#111c2d]">WiFi Configuration</div>
                  <div className="text-[10px] text-[#737686] mt-0.5">{config.ssid || 'Not Configured'}</div>
                </div>
              </div>
              <span className="material-symbols-outlined text-[#737686] text-sm">chevron_right</span>
            </button>

            {/* Firmware Version */}
            <div className="w-full flex items-center justify-between p-4 bg-white rounded-xl shadow-sm border border-[#c3c6d7]/20">
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-full bg-[#f0f3ff] text-[#737686] flex items-center justify-center">
                  <span className="material-symbols-outlined text-lg">system_update</span>
                </div>
                <div>
                  <div className="text-xs font-bold text-[#111c2d]">Firmware Version</div>
                  <div className="text-[10px] text-[#737686] mt-0.5">{config.firmware}</div>
                </div>
              </div>
              <span className="px-2.5 py-0.5 bg-[#7cf994] text-[#007230] rounded-full text-[9px] font-bold uppercase tracking-wider">
                Latest
              </span>
            </div>

            {/* Restart Device */}
            <button
              onClick={onRestartDevice}
              className="w-full flex items-center justify-between p-4 bg-white rounded-xl shadow-sm border border-[#c3c6d7]/20 hover:bg-[#ffdad6]/20 transition-colors text-left group"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-full bg-[#ffdad6]/40 text-[#ba1a1a] flex items-center justify-center">
                  <span className="material-symbols-outlined text-lg">restart_alt</span>
                </div>
                <div>
                  <div className="text-xs font-bold text-[#111c2d] group-hover:text-[#ba1a1a] transition-colors">
                    Restart Dispenser
                  </div>
                  <div className="text-[10px] text-[#737686] mt-0.5">Reboot physical hardware hub</div>
                </div>
              </div>
              <span className="material-symbols-outlined text-[#737686] text-sm">chevron_right</span>
            </button>
          </div>
        </section>

        {/* App Settings */}
        <section className="space-y-3">
          <div className="flex items-center gap-2 px-1 text-[#737686]">
            <span className="material-symbols-outlined text-base">settings</span>
            <h3 className="text-[10px] font-bold uppercase tracking-wider">Application Settings</h3>
          </div>

          <div className="space-y-2.5">
            {/* Dark Mode */}
            <label className="w-full flex items-center justify-between p-4 bg-white rounded-xl shadow-sm border border-[#c3c6d7]/20 cursor-pointer">
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-full bg-[#f0f3ff] text-[#737686] flex items-center justify-center">
                  <span className="material-symbols-outlined text-lg">dark_mode</span>
                </div>
                <div className="text-xs font-bold text-[#111c2d]">Dark Theme (Visual)</div>
              </div>
              <div className="relative inline-block w-11 h-6">
                <input
                  type="checkbox"
                  checked={isDarkMode}
                  onChange={onToggleDarkMode}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-[#c3c6d7] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#004ac6]"></div>
              </div>
            </label>

            {/* Notifications */}
            <button
              onClick={() => alert('Notification settings are configured securely for mobile reminders.')}
              className="w-full flex items-center justify-between p-4 bg-white rounded-xl shadow-sm border border-[#c3c6d7]/20 hover:bg-[#f0f3ff] transition-colors text-left"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-full bg-[#f0f3ff] text-[#737686] flex items-center justify-center">
                  <span className="material-symbols-outlined text-lg">notifications_active</span>
                </div>
                <div>
                  <div className="text-xs font-bold text-[#111c2d]">Notifications &amp; Alerts</div>
                  <div className="text-[10px] text-[#737686] mt-0.5">Reminders, critical hardware errors</div>
                </div>
              </div>
              <span className="material-symbols-outlined text-[#737686] text-sm">chevron_right</span>
            </button>

            {/* Sound */}
            <button
              onClick={() => alert('Chime volume adjusted to 80% for patient acoustics.')}
              className="w-full flex items-center justify-between p-4 bg-white rounded-xl shadow-sm border border-[#c3c6d7]/20 hover:bg-[#f0f3ff] transition-colors text-left"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-full bg-[#f0f3ff] text-[#737686] flex items-center justify-center">
                  <span className="material-symbols-outlined text-lg">volume_up</span>
                </div>
                <div>
                  <div className="text-xs font-bold text-[#111c2d]">Acoustics &amp; Chimes</div>
                  <div className="text-[10px] text-[#737686] mt-0.5">Dispenser buzzer alarm at 80%</div>
                </div>
              </div>
              <span className="material-symbols-outlined text-[#737686] text-sm">chevron_right</span>
            </button>
          </div>
        </section>

        {/* System Info Section */}
        <section className="space-y-3">
          <div className="flex items-center gap-2 px-1 text-[#737686]">
            <span className="material-symbols-outlined text-base">info</span>
            <h3 className="text-[10px] font-bold uppercase tracking-wider">System Information</h3>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {/* About Nav */}
            <button
              onClick={() => onNavigate('about')}
              className="flex items-center justify-between p-4 bg-white rounded-xl shadow-sm border border-[#c3c6d7]/20 hover:bg-[#f0f3ff] transition-colors text-left"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-[#f0f3ff] text-[#737686] flex items-center justify-center shrink-0">
                  <span className="material-symbols-outlined text-base">help</span>
                </div>
                <div>
                  <div className="text-xs font-bold text-[#111c2d]">About Project</div>
                  <div className="text-[9px] text-[#737686] mt-0.5">Legal, Team Info</div>
                </div>
              </div>
            </button>

            {/* Developer Mode */}
            <div className="flex items-center justify-between p-4 bg-white rounded-xl shadow-sm border border-[#c3c6d7]/20">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-[#f0f3ff] text-[#737686] flex items-center justify-center shrink-0">
                  <span className="material-symbols-outlined text-base">code</span>
                </div>
                <div>
                  <div className="text-xs font-bold text-[#111c2d]">Developer Mode</div>
                  <div className="text-[9px] text-red-600 font-bold mt-0.5">Disabled</div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* Settings Footer Logo */}
      <footer className="mt-8 flex flex-col items-center justify-center opacity-40">
        <span className="material-symbols-outlined text-2xl text-[#004ac6]">medical_services</span>
        <p className="text-[10px] font-semibold text-[#111c2d] mt-1">MedLink IoT • Patient Safety First</p>
      </footer>
    </div>
  );
}
