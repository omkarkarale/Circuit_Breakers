package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.Medication
import com.example.data.MedicationDatabase
import com.example.data.MedicationLog
import com.example.data.MedicationRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MedicationViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: MedicationRepository

    val medications: StateFlow<List<Medication>>
    val logs: StateFlow<List<MedicationLog>>

    // IoT Hub State
    private val _hubConnected = MutableStateFlow(true)
    val hubConnected = _hubConnected.asStateFlow()

    private val _hubBattery = MutableStateFlow(85)
    val hubBattery = _hubBattery.asStateFlow()

    private val _countdownSeconds = MutableStateFlow(5037) // 1 hour 23 mins 57 secs
    val countdownSeconds = _countdownSeconds.asStateFlow()

    // Wi-Fi Config
    private val _wifiSSID = MutableStateFlow("Home_Network_5G")
    val wifiSSID = _wifiSSID.asStateFlow()

    private val _wifiPassword = MutableStateFlow("password123")
    val wifiPassword = _wifiPassword.asStateFlow()

    private val _isConnectingWifi = MutableStateFlow(false)
    val isConnectingWifi = _isConnectingWifi.asStateFlow()

    // Theme Settings
    private val _isDarkTheme = MutableStateFlow(false)
    val isDarkTheme = _isDarkTheme.asStateFlow()

    // Engineering Diagnostics States
    private val _temperature = MutableStateFlow(34.2f)
    val temperature = _temperature.asStateFlow()

    private val _componentStates = MutableStateFlow(
        mapOf(
            "Stepper Motor 1" to "WORKING",
            "Stepper Motor 2" to "WORKING",
            "Stepper Motor 3" to "WARNING",
            "RTC Module" to "WORKING",
            "IR Sensor" to "OFFLINE",
            "Speaker" to "WORKING",
            "OLED Display" to "WORKING",
            "WiFi Stack" to "WORKING",
            "REST API Gateway" to "WORKING"
        )
    )
    val componentStates = _componentStates.asStateFlow()

    private val _isTestingComponent = MutableStateFlow<String?>(null)
    val isTestingComponent = _isTestingComponent.asStateFlow()

    private val _isFullDiagnosing = MutableStateFlow(false)
    val isFullDiagnosing = _isFullDiagnosing.asStateFlow()

    init {
        val database = MedicationDatabase.getDatabase(application, viewModelScope)
        repository = MedicationRepository(database.medicationDao(), database.medicationLogDao())
        
        medications = repository.allMedications.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        logs = repository.allLogs.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        // Launch simulated background countdown for dispenser timer
        viewModelScope.launch {
            while (true) {
                delay(1000)
                if (_countdownSeconds.value > 0) {
                    _countdownSeconds.value -= 1
                } else {
                    _countdownSeconds.value = 28800 // Reset to 8 hours
                }
            }
        }
    }

    fun toggleTheme() {
        _isDarkTheme.value = !_isDarkTheme.value
    }

    fun updateWifiSSID(ssid: String) {
        _wifiSSID.value = ssid
    }

    fun updateWifiPassword(pass: String) {
        _wifiPassword.value = pass
    }

    fun connectDevice(onComplete: () -> Unit) {
        viewModelScope.launch {
            _isConnectingWifi.value = true
            _hubConnected.value = false
            delay(2500) // Simulating network handshake and connection sequence
            _hubConnected.value = true
            _isConnectingWifi.value = false
            onComplete()
            
            // Log connection success
            addLog(
                medicationName = "IoT Hub",
                dosage = "System Config",
                status = "Taken",
                description = "Successfully configured Wi-Fi SSID '${_wifiSSID.value}' and reconnected smart dispenser hub.",
                categoryDate = "Today"
            )
        }
    }

    fun addMedication(
        name: String,
        dosage: String,
        type: String,
        colorHex: String,
        slot: Int,
        pillsRemaining: Int,
        dosePerReminder: Int,
        repeatPattern: String,
        scheduleTimes: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val med = Medication(
                name = name,
                dosage = dosage,
                type = type,
                colorHex = colorHex,
                slot = slot,
                pillsRemaining = pillsRemaining,
                maxCapacity = 30,
                dosePerReminder = dosePerReminder,
                repeatPattern = repeatPattern,
                scheduleTimes = scheduleTimes,
                isEnabled = true,
                streakDays = 0
            )
            repository.insertMedication(med)

            // Add action log
            addLog(
                medicationName = name,
                dosage = dosage,
                status = "Taken",
                description = "Added to smart dispenser Slot #$slot schedule. Auto-sync finalized.",
                categoryDate = "Today"
            )
        }
    }

    fun refillAll() {
        viewModelScope.launch(Dispatchers.IO) {
            medications.value.forEach { med ->
                repository.insertMedication(med.copy(pillsRemaining = med.maxCapacity))
            }
            addLog(
                medicationName = "Inventory",
                dosage = "All Medications",
                status = "Taken",
                description = "Inventory successfully restocked to full capacities on all active slot channels.",
                categoryDate = "Today"
            )
        }
    }

    fun refillMedication(medication: Medication) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = medication.copy(pillsRemaining = medication.maxCapacity)
            repository.insertMedication(updated)
            addLog(
                medicationName = medication.name,
                dosage = medication.dosage,
                status = "Taken",
                description = "Inventory refilled. Added ${medication.maxCapacity - medication.pillsRemaining} pills to Slot #${medication.slot}.",
                categoryDate = "Today"
            )
        }
    }

    fun toggleMedicationEnabled(medication: Medication, enabled: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = medication.copy(isEnabled = enabled)
            repository.insertMedication(updated)
            addLog(
                medicationName = medication.name,
                dosage = medication.dosage,
                status = if (enabled) "Taken" else "Cancelled",
                description = if (enabled) "Dispenser channel Slot #${medication.slot} is enabled." else "Dispenser channel Slot #${medication.slot} has been disabled.",
                categoryDate = "Today"
            )
        }
    }

    fun deleteMedication(id: Int, medName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteMedicationById(id)
            addLog(
                medicationName = medName,
                dosage = "Removed",
                status = "Cancelled",
                description = "Medication removed from dispenser schedule list database.",
                categoryDate = "Today"
            )
        }
    }

    fun testDispense(medication: Medication, onComplete: (Boolean) -> Unit) {
        viewModelScope.launch {
            _isTestingComponent.value = "Slot #${medication.slot}"
            delay(2000) // Simulating physical gear motor motion
            
            val success = medication.isEnabled && medication.pillsRemaining >= medication.dosePerReminder
            if (success) {
                val newRemaining = (medication.pillsRemaining - medication.dosePerReminder).coerceAtLeast(0)
                repository.updatePillsRemaining(medication.id, newRemaining)
                
                addLog(
                    medicationName = medication.name,
                    dosage = medication.dosage,
                    status = "Taken",
                    description = "Test Dispense succeeded! Dropped ${medication.dosePerReminder} pill(s) from SmartBox Slot #${medication.slot}.",
                    categoryDate = "Today"
                )
            } else {
                addLog(
                    medicationName = medication.name,
                    dosage = medication.dosage,
                    status = "Failed",
                    description = "Test Dispense failed on Slot #${medication.slot}. Slot disabled or empty.",
                    categoryDate = "Today"
                )
            }
            _isTestingComponent.value = null
            onComplete(success)
        }
    }

    fun runComponentTest(componentName: String) {
        viewModelScope.launch {
            _isTestingComponent.value = componentName
            delay(1500) // Simulating component diagnostic self-test
            
            val currentMap = _componentStates.value.toMutableMap()
            if (componentName == "IR Sensor") {
                // Clicking reset online
                currentMap[componentName] = "WORKING"
                _componentStates.value = currentMap
                addLog(
                    medicationName = "IR Sensor",
                    dosage = "Hardware Debug",
                    status = "Taken",
                    description = "IR Obstruction Sensor calibration reset completed. Status returned to Working.",
                    categoryDate = "Today"
                )
            } else if (componentName == "Stepper Motor 3") {
                // Warming up / lubrication success
                currentMap[componentName] = "WORKING"
                _componentStates.value = currentMap
                addLog(
                    medicationName = "Motor 3",
                    dosage = "Stepper Test",
                    status = "Taken",
                    description = "Stepper Motor 3 friction test recalibrated successfully.",
                    categoryDate = "Today"
                )
            } else {
                addLog(
                    medicationName = componentName,
                    dosage = "Diag Loop",
                    status = "Taken",
                    description = "$componentName self-test diagnostics completed. Feedback signature verified successfully.",
                    categoryDate = "Today"
                )
            }
            _isTestingComponent.value = null
        }
    }

    fun runFullDiagnostics(onComplete: () -> Unit) {
        viewModelScope.launch {
            _isFullDiagnosing.value = true
            delay(2500) // Engineering diagnostic sweeps
            
            // Clear errors
            val currentMap = _componentStates.value.toMutableMap()
            currentMap["Stepper Motor 3"] = "WORKING"
            currentMap["IR Sensor"] = "WORKING"
            _componentStates.value = currentMap
            _temperature.value = 32.5f // cool down
            
            _isFullDiagnosing.value = false
            onComplete()

            addLog(
                medicationName = "System",
                dosage = "All Sensors",
                status = "Taken",
                description = "Completed full engineering hardware system audit. All slots clear. Temperature nominal.",
                categoryDate = "Today"
            )
        }
    }

    private suspend fun addLog(
        medicationName: String,
        dosage: String,
        status: String,
        description: String,
        categoryDate: String
    ) {
        repository.insertLog(
            MedicationLog(
                medicationName = medicationName,
                dosage = dosage,
                timestamp = System.currentTimeMillis(),
                status = status,
                description = description,
                categoryDate = categoryDate
            )
        )
    }

    fun getFormattedCountdown(): String {
        val seconds = _countdownSeconds.value
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60
        return String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
    }
}
