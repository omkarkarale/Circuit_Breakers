package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

@Entity(tableName = "medications")
data class Medication(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val type: String, // Tablet, Capsule, Softgel
    val colorHex: String,
    val slot: Int, // 1, 2, 3
    val pillsRemaining: Int,
    val maxCapacity: Int = 30,
    val dosePerReminder: Int,
    val repeatPattern: String, // Daily, Weekdays, Custom
    val scheduleTimes: String, // comma-separated e.g. "08:00 AM, 09:00 PM"
    val isEnabled: Boolean = true,
    val lastTakenTime: String? = null,
    val streakDays: Int = 0,
    val dosage: String = "500mg" // extra field for medication strength
)

@Entity(tableName = "medication_logs")
data class MedicationLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val medicationName: String,
    val dosage: String,
    val timestamp: Long,
    val status: String, // Taken, Cancelled, Failed, Missed
    val description: String,
    val categoryDate: String // Today, Yesterday, Older
)

@Dao
interface MedicationDao {
    @Query("SELECT * FROM medications ORDER BY slot ASC")
    fun getAllMedicationsFlow(): Flow<List<Medication>>

    @Query("SELECT * FROM medications WHERE id = :id LIMIT 1")
    suspend fun getMedicationById(id: Int): Medication?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMedication(medication: Medication)

    @Query("DELETE FROM medications WHERE id = :id")
    suspend fun deleteMedicationById(id: Int)

    @Query("UPDATE medications SET pillsRemaining = :pillsRemaining WHERE id = :id")
    suspend fun updatePillsRemaining(id: Int, pillsRemaining: Int)

    @Query("UPDATE medications SET isEnabled = :enabled WHERE id = :id")
    suspend fun updateEnabledStatus(id: Int, enabled: Boolean)
}

@Dao
interface MedicationLogDao {
    @Query("SELECT * FROM medication_logs ORDER BY timestamp DESC")
    fun getAllLogsFlow(): Flow<List<MedicationLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: MedicationLog)

    @Query("DELETE FROM medication_logs")
    suspend fun clearLogs()
}

@Database(entities = [Medication::class, MedicationLog::class], version = 1, exportSchema = false)
abstract class MedicationDatabase : RoomDatabase() {
    abstract fun medicationDao(): MedicationDao
    abstract fun medicationLogDao(): MedicationLogDao

    companion object {
        @Volatile
        private var INSTANCE: MedicationDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): MedicationDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MedicationDatabase::class.java,
                    "medlink_database"
                )
                .addCallback(MedicationDatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class MedicationDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateDatabase(database.medicationDao(), database.medicationLogDao())
                }
            }
        }

        suspend fun populateDatabase(medDao: MedicationDao, logDao: MedicationLogDao) {
            // Seed initial Medications
            medDao.insertMedication(
                Medication(
                    name = "Aspirin",
                    dosage = "100mg",
                    type = "Tablet",
                    colorHex = "#2196F3",
                    slot = 1,
                    pillsRemaining = 45,
                    maxCapacity = 50,
                    dosePerReminder = 1,
                    repeatPattern = "Daily",
                    scheduleTimes = "02:00 PM",
                    isEnabled = true,
                    lastTakenTime = "Today, 02:05 PM",
                    streakDays = 5
                )
            )

            medDao.insertMedication(
                Medication(
                    name = "Metformin",
                    dosage = "500mg",
                    type = "Capsule",
                    colorHex = "#4CAF50",
                    slot = 2,
                    pillsRemaining = 8,
                    maxCapacity = 30,
                    dosePerReminder = 2,
                    repeatPattern = "Daily",
                    scheduleTimes = "08:00 AM, 08:00 PM",
                    isEnabled = true,
                    lastTakenTime = "Today, 08:05 AM",
                    streakDays = 12
                )
            )

            medDao.insertMedication(
                Medication(
                    name = "Lisinopril",
                    dosage = "10mg",
                    type = "Softgel",
                    colorHex = "#9C27B0",
                    slot = 3,
                    pillsRemaining = 12,
                    maxCapacity = 30,
                    dosePerReminder = 1,
                    repeatPattern = "Daily",
                    scheduleTimes = "10:30 AM",
                    isEnabled = false,
                    lastTakenTime = null,
                    streakDays = 0
                )
            )

            // Seed initial Medication Logs
            val currentTime = System.currentTimeMillis()
            val dayMillis = 24 * 60 * 60 * 1000L

            logDao.insertLog(
                MedicationLog(
                    medicationName = "Metformin",
                    dosage = "500mg Oral",
                    timestamp = currentTime - (2 * 60 * 60 * 1000L), // 2 hours ago
                    status = "Taken",
                    description = "Dispensed successfully from SmartBox Slot A2.",
                    categoryDate = "Today"
                )
            )

            logDao.insertLog(
                MedicationLog(
                    medicationName = "Lisinopril",
                    dosage = "10mg Oral",
                    timestamp = currentTime - (5 * 60 * 60 * 1000L), // 5 hours ago
                    status = "Cancelled",
                    description = "Manual override by user. Stated \"Will take later with meal\".",
                    categoryDate = "Today"
                )
            )

            logDao.insertLog(
                MedicationLog(
                    medicationName = "Atorvastatin",
                    dosage = "20mg Oral",
                    timestamp = currentTime - dayMillis, // Yesterday
                    status = "Failed",
                    description = "IoT Device Hardware Jam detected in Slot C1. Please inspect device.",
                    categoryDate = "Yesterday"
                )
            )

            logDao.insertLog(
                MedicationLog(
                    medicationName = "Vitamin D3",
                    dosage = "1000 IU",
                    timestamp = currentTime - dayMillis - (4 * 60 * 60 * 1000L),
                    status = "Missed",
                    description = "No response to 3 repeated alerts. Window closed at 02:00 PM.",
                    categoryDate = "Yesterday"
                )
            )

            logDao.insertLog(
                MedicationLog(
                    medicationName = "Metformin",
                    dosage = "500mg Oral",
                    timestamp = currentTime - dayMillis - (8 * 60 * 60 * 1000L),
                    status = "Taken",
                    description = "Dispensed successfully. Adherence streak: 12 days.",
                    categoryDate = "Yesterday"
                )
            )
        }
    }
}

class MedicationRepository(
    private val medicationDao: MedicationDao,
    private val medicationLogDao: MedicationLogDao
) {
    val allMedications: Flow<List<Medication>> = medicationDao.getAllMedicationsFlow()
    val allLogs: Flow<List<MedicationLog>> = medicationLogDao.getAllLogsFlow()

    suspend fun getMedicationById(id: Int): Medication? = medicationDao.getMedicationById(id)

    suspend fun insertMedication(medication: Medication) = medicationDao.insertMedication(medication)

    suspend fun deleteMedicationById(id: Int) = medicationDao.deleteMedicationById(id)

    suspend fun updatePillsRemaining(id: Int, pills: Int) = medicationDao.updatePillsRemaining(id, pills)

    suspend fun updateEnabledStatus(id: Int, enabled: Boolean) = medicationDao.updateEnabledStatus(id, enabled)

    suspend fun insertLog(log: MedicationLog) = medicationLogDao.insertLog(log)

    suspend fun clearLogs() = medicationLogDao.clearLogs()
}
